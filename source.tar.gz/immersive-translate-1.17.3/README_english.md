# About this Repository

This repository is used to release the Immersive Translate [Release Versions](https://github.com/immersive-translate/immersive-translate/releases) and collect and track user feedback via [Github Issues](https://github.com/immersive-translate/immersive-translate/issues).

[Immersive Translate](https://immersivetranslate.com/) is not open source software, this repository **DOES NOT** contain the source code of Immersive Translate.

> The old version of the [Immersive Translate Open Source Project](github.com/immersive-translate/old-immersive-translate) was archived on January 17, 2023.

[**Click to Install Immersive Translate**](https://immersivetranslate.com/docs/installation/)

Below is a video introduction:

https://github.com/immersive-translate/immersive-translate/assets/62473795/a0e9af51-4a18-45ef-9fc4-0a1509d56ab0
